from kivy.app import App
from kivy.lang import Builder
from datetime import datetime
from kivy.core.audio import SoundLoader
from kivy.uix.label import Label
import time

data_atual = datetime.today()


def dates_dif(date_qr, current_date):
    return (date_qr - current_date).days


class MainApp(App):
    dentro_sound_sp1 = None
    dentro_sound_sp2 = None
    dentro_sound_sp3 = None
    dentro_sound_sp4 = None
    fora_sound_sp1 = None
    fora_sound_sp2 = None
    fora_sound_sp3 = None
    fora_sound_sp4 = None
    code = ''
    vel = 1
    calar = False

    def build(self):

        return Builder.load_string(
"""
#:import ZBarCam kivy_garden.zbarcam.ZBarCam
FloatLayout:
    orientation: 'vertical'
    Button:
        id: botao_calar
        pos_hint:{"right": 1, "top": 1}
        size_hint: 1, 0.1
        source: "Mute_Icon.png"
        on_release:
            app.calar_voz()
    ZBarCam:
        pos_hint:{"right": 1, "top": 0.90}
        size_hint: 1, 0.70
        id: qrcodecam
    Label:
        pos_hint:{"right": 1, "top": 0.2}
        size_hint: 1, 0.1
        font_size: 30
        text: app.print_code(', '.join([str(symbol.data) for symbol in qrcodecam.symbols]))
    Button:
        id: speed_button
        text: "Acelerar"
        pos_hint:{"right": 1, "top": 0.10}
        size_hint: 1, 0.1
        on_release:
            app.mudar_reproducao()
        font_size: 32
"""
)

    def on_start(self):
        if self.dentro_sound_sp1 == None:
            self.dentro_sound_sp1 = SoundLoader.load('Dentro da validade 1.0x.wav'.format(self.vel))
            self.dentro_sound_sp2 = SoundLoader.load('Dentro da validade 1.2x.wav'.format(self.vel))
            self.dentro_sound_sp3 = SoundLoader.load('Dentro da validade 1.5x.wav'.format(self.vel))
            self.dentro_sound_sp4 = SoundLoader.load('Dentro da validade 2.0x.wav'.format(self.vel))
            self.fora_sound_sp1 = SoundLoader.load('Fora da validade 1.0x.wav'.format(self.vel))
            self.fora_sound_sp2 = SoundLoader.load('Fora da validade 1.2x.wav'.format(self.vel))
            self.fora_sound_sp3 = SoundLoader.load('Fora da validade 1.5x.wav'.format(self.vel))
            self.fora_sound_sp4 = SoundLoader.load('Fora da validade 2.0x.wav'.format(self.vel))

    def mudar_reproducao(self):
        self.vel += 1
        if self.vel == 5:
            self.vel = 1

    def calar_voz(self):
        if self.calar:
            self.calar = False
        else:
            self.calar = True

    def print_code(self, code):
        code = code[2:12]
        code = str(code)
        if self.calar:
            return code
        try:
            code_dt = datetime.strptime(code, '%d/%m/%Y')
            if dates_dif(code_dt, data_atual) >= 0:
                # print('Dentro da validade')
                if self.vel == 1:
                    self.dentro_sound_sp1.play()
                    time.sleep(2)
                elif self.vel == 2:
                    self.dentro_sound_sp2.play()
                    time.sleep(1.75)
                elif self.vel == 3:
                    self.dentro_sound_sp3.play()
                    time.sleep(1)
                else:
                    self.dentro_sound_sp4.play()
                    time.sleep(0.5)

            else:
                # print('Fora da validade')
                if self.vel == 1:
                    self.fora_sound_sp1.play()
                    time.sleep(2)
                elif self.vel == 2:
                    self.fora_sound_sp2.play()
                    time.sleep(1.75)
                elif self.vel == 3:
                    self.fora_sound_sp3.play()
                    time.sleep(1)
                else:
                    self.fora_sound_sp4.play()
                    time.sleep(0.5)

        except:
            return ''
            # # print('Invalido')
            # self.invalido_sound.play()
            # if self.vel == 1.0:
            #     time.sleep(2)
            # elif self.vel == 1.2:
            #     time.sleep(1.75)
            # elif self.vel == 1.5:
            #     time.sleep(1)
            # else:
            #     time.sleep(0.5)
        self.code = str(code)
        return self.code



MainApp().run()
