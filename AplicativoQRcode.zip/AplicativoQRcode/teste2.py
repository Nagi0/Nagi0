from datetime import datetime
import time
import os, psutil

data = input('Digite a data de validade: ')
inicial = time.time()

data = datetime.strptime(data, '%d/%m/%Y')

data_atual = datetime.today()


def dates_dif(date_qr, current_date):
    return (date_qr - current_date).days


#print('Diferença em Dias: ', dates_dif(data, data_atual))

if dates_dif(data, data_atual) >= 0:
    print('Dentro da Validade')
else:
    print('Fora da Validade')

final = time.time()

tempo_processo = final-inicial
print('The CPU usage is: ', psutil.cpu_percent(tempo_processo))
print('RAM memory % used:', psutil.virtual_memory().percent)
print('Tempo de processamento: ',tempo_processo)

# print('Data: ', data)
# print('Data Atual: ', data_atual)
# print(dates_dif(data, data_atual))