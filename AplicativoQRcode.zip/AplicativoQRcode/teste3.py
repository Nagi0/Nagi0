from playsound import playsound

playsound('Dentro da validade.mp3')