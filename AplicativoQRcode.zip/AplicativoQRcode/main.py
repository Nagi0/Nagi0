from kivy.app import App
from kivy.lang import Builder
from datetime import datetime
from kivy.core.audio import SoundLoader
import time

data_atual = datetime.today()


def dates_dif(date_qr, current_date):
    return (date_qr - current_date).days


class MainApp(App):
    dentro_sound = None
    fora_sound = None
    invalido_sound = None
    vel = 1.0

    def build(self):

        return Builder.load_string(
"""
#:import ZBarCam kivy_garden.zbarcam.ZBarCam
BoxLayout:
    orientation: 'vertical'
    ZBarCam:
        id: qrcodecam
    Label:
        size_hint: None, None
        size: self.texture_size[0], 50
        text: ', '.join([str(symbol.data) for symbol in qrcodecam.symbols])
    Button:
        size_hint: 1, 1
        pos_hint:{"right": 1, "top": 0.5}
        on_release:
            app.print_code(', '.join([str(symbol.data) for symbol in qrcodecam.symbols]))
    Button:
        pos_hint:{"right": 1, "top": 0.25}
        size_hint: 1, 0.3
        on_release:
            app.mudar_reproducao()
"""
)

    def on_start(self):
        if self.dentro_sound == None:
            self.dentro_sound = SoundLoader.load('Dentro da validade {}x.wav'.format(self.vel))
            self.fora_sound = SoundLoader.load('Fora da validade {}x.wav'.format(self.vel))
            self.invalido_sound = SoundLoader.load('Codigo Invalido {}x.wav'.format(self.vel))

        pass

    def mudar_reproducao(self):
        if self.vel == 1.0:
            self.vel += 0.2
        elif self.vel == 1.2:
            self.vel = 1.5
        elif self.vel == 1.5:
            self.vel = 2.0
        elif self.vel == 2.0:
            self.vel = 1.0
        self.dentro_sound = SoundLoader.load('Dentro da validade {}x.wav'.format(self.vel))
        self.fora_sound = SoundLoader.load('Fora da validade {}x.wav'.format(self.vel))
        self.invalido_sound = SoundLoader.load('Codigo Invalido {}x.wav'.format(self.vel))

    def print_code(self, code):
        code = code[2:12]
        code = str(code)
        try:
            code = datetime.strptime(code, '%d/%m/%Y')
            if dates_dif(code, data_atual) >= 0:
                # print('Dentro da validade')
                self.dentro_sound.play()
                if self.vel == 1.0:
                    time.sleep(2)
                elif self.vel == 1.2:
                    time.sleep(1.75)
                elif self.vel == 1.5:
                    time.sleep(1)
                else:
                    time.sleep(0.5)

            else:
                # print('Fora da validade')
                self.fora_sound.play()
                if self.vel == 1.0:
                    time.sleep(2)
                elif self.vel == 1.2:
                    time.sleep(1.75)
                elif self.vel == 1.5:
                    time.sleep(1)
                else:
                    time.sleep(0.5)

        except:
            # print('Invalido')
            self.invalido_sound.play()
            if self.vel == 1.0:
                time.sleep(2)
            elif self.vel == 1.2:
                time.sleep(1.75)
            elif self.vel == 1.5:
                time.sleep(1)
            else:
                time.sleep(0.5)



MainApp().run()
