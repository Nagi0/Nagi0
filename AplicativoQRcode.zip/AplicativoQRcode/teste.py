import time
import os, psutil

data = input('Digite a data de validade: ')
inicial = time.time()

data_atual = time.localtime()
data_hora = {'ano': data_atual.tm_year,
             'mes': data_atual.tm_mon,
             'dia': data_atual.tm_mday,
             'hora': data_atual.tm_hour,
             'dia da semana': data_atual.tm_wday
             }

dia_v = data[0:2]
mes_v = data[3:5]
ano_v = data[6:]

if (int(data_hora['mes'])) > (int(mes_v)) or (int(data_hora['ano'])) > (int(ano_v)):
    print('passou da validade')

elif (int(data_hora['dia'])) > (int(dia_v)) and (int(data_hora['mes']) == (int(mes_v))) and \
        (int(data_hora['ano']) == (int(ano_v))):
    print('passou da validade')

else:
    print('dentro da validade')

final = time.time()

tempo_processo = final-inicial
print('The CPU usage is: ', psutil.cpu_percent(tempo_processo))
print('RAM memory % used:', psutil.virtual_memory().percent)
print('Tempo de processamento: ',tempo_processo)